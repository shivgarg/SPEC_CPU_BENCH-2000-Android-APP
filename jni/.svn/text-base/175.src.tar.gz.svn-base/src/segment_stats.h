void save_segment_type_and_length_info (t_seg_details *seg_details_x, int 
      nodes_per_xchan, t_seg_details *seg_details_y, int nodes_per_ychan);

void get_segment_usage_stats (int num_segment); 
